# Project Figures

These figures are used in the main project README.

1. **Present Value Decay** — `present_value_decay.png`
2. **Milestone Comparison** — `milestone_comparison.png`
3. **Sensitivity Heatmap** — `sensitivity_heatmap.png`
