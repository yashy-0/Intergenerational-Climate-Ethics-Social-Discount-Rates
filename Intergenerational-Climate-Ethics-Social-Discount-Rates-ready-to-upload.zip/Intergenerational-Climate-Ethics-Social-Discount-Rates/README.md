# Intergenerational Climate Ethics & Social Discount Rates

## Overview

This project investigates how ethical assumptions about the social discount rate affect the present valuation of long-term climate damages.

The central question is:

> **How much does the present value of future climate damages change when we vary the ethical parameters used to discount the welfare of future generations?**

The analysis combines economic discounting with an explicitly intergenerational ethical question. Rather than treating the discount rate as a purely technical parameter, the model explores how different assumptions about the value of future welfare can produce dramatically different valuations of damages occurring decades or centuries from now.

## Research Framework

The analysis focuses on the Ramsey-style social discounting framework:

\[
r = \rho + \eta g
\]

where:

- \(r\) = social discount rate
- \(\rho\) = pure rate of time preference
- \(\eta\) = elasticity of marginal utility of consumption
- \(g\) = growth rate of consumption

These parameters have both economic and normative interpretations. In particular, the pure rate of time preference determines how much less weight is assigned to future welfare simply because it occurs later.

The project therefore examines not only the numerical consequences of discounting, but also the ethical significance of the assumptions underlying those calculations.

---

## Results

### 1. Present Value Decay Over Time

The first figure shows how the present value assigned to a fixed future climate-damage stream declines as the damages move further into the future under different discounting assumptions.

![Present value decay over time](figures/present_value_decay.png)

**Interpretation:** Small differences in discount rates compound substantially over long horizons. As the time horizon increases, scenarios with higher discount rates assign progressively less present value to future damages. This illustrates why the choice of discount rate can become especially consequential in climate policy, where relevant damages may occur many decades or centuries in the future.

---

### 2. Milestone Comparison

The second figure compares the present value assigned to damages occurring at several time horizons.

![Milestone comparison](figures/milestone_comparison.png)

**Interpretation:** The divergence between discounting assumptions becomes increasingly pronounced at longer horizons. The same future damage can therefore have substantially different present valuations depending on the ethical and economic assumptions used to discount it.

---

### 3. Sensitivity to Ethical Parameters

The heatmap examines how the present value changes across combinations of the key ethical parameters.

![Sensitivity heatmap](figures/sensitivity_heatmap.png)

The plotted reference points correspond to parameter choices associated with prominent positions in the social-discounting literature.

**Interpretation:** The heatmap demonstrates that the valuation of future climate damages is highly sensitive to the parameters governing intertemporal welfare. In particular, combinations involving a low pure rate of time preference can place substantially greater present weight on distant generations.

This is important because it shows that disagreements about climate policy can arise not only from different empirical forecasts, but also from different normative judgments about how present and future welfare should be compared.

---

## Why This Matters

Climate change creates an unusually long intertemporal policy problem. A policymaker today may have to compare:

- costs borne by the current generation,
- benefits received decades later,
- and climate damages experienced by people who do not yet exist.

Social discounting provides one mathematical framework for making those comparisons. But the framework embeds normative assumptions about intergenerational justice.

A central implication of this project is therefore:

> **The social discount rate is not merely a technical input into a cost-benefit calculation; its parameters encode judgments about how much moral weight should be given to future generations.**

---

## Methodology

The project uses computational analysis in R to:

1. Specify alternative social-discounting assumptions.
2. Calculate the present value of future climate damages.
3. Evaluate the effect of different time horizons.
4. Compare alternative parameter choices.
5. Conduct sensitivity analysis across the ethical parameters.
6. Visualize the resulting differences using line charts, milestone comparisons, and heatmaps.

The figures in this repository are generated from the underlying computational analysis rather than being manually constructed illustrations.

---

## Figures

All project figures are stored in the [`figures`](figures/) directory:

- `present_value_decay.png` — present value as a function of time horizon
- `milestone_comparison.png` — comparison at selected time horizons
- `sensitivity_heatmap.png` — sensitivity to social-discounting parameters

---

## Limitations

This analysis is intended as a sensitivity and conceptual analysis rather than a complete integrated assessment model of climate change.

Important limitations include:

- The results depend on assumptions about future consumption growth and climate damages.
- A fixed damage stream does not capture the full uncertainty surrounding climate impacts.
- The Ramsey framework is only one approach to social discounting.
- Ethical judgments about intergenerational welfare cannot be resolved by computation alone.
- The numerical results should therefore be interpreted as illustrating the consequences of assumptions rather than establishing a single objectively correct discount rate.

---

## Reproducibility

The computational analysis is written in R. To reproduce the figures, run the relevant R scripts contained in the repository.

The repository is structured so that the generated figures can be viewed independently from the code.

---

## Intellectual Motivation

The project sits at the intersection of **economics, philosophy, and climate policy**.

The economic question is how future costs should be valued in present decision-making. The philosophical question is whether people living in the future should receive less moral consideration merely because they live later. The computational analysis connects these questions by showing how different normative assumptions translate into quantitatively different policy valuations.

